# lxd

This plugin provides completion for [lxd](https://linuxcontainers.org/lxd/), as well as aliases
for frequent lxc commands.

To use it add `lxd` to the plugins array in your zshrc file.

```zsh
plugins=(... lxd)
